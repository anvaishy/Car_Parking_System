package com.DASH.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {
	
	@GetMapping("/userlogin")
	public String login() {
		return "userlogin";
	}	
	@GetMapping("/userdashboard")
	public String home() {
		return "userdashboard";
	}
	@RequestMapping("/admin")
	public String admin() {
		return "admindash";
	}
	@RequestMapping("/")
	public String adminsub() {
		return "test";
	}
	@RequestMapping("/adminlogin")
	public String adsub() {
		return "testing";
	}
	@RequestMapping("/workerlogin")
	public String wlogin() {
		return "workerlogin";
	}
	@RequestMapping("/workerdashboard")
	public String workerdash() {
		return "workerdashboard";
	}

}
